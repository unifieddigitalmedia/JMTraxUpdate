# Just-Money-Transfers
Just Money Transfers is an Android App. This is the complete souce code for Just Money Transfers App which is waiting for completeion of user testing before being published to Google Play.
