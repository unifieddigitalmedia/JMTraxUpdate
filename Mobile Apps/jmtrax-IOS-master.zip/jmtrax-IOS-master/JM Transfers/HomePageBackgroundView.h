//
//  HomePageBackgroundView.h
//  JM Transfers
//
//  Created by Machel Slack on 05/12/2015.
//  Copyright © 2015 Just Computers Parts. All rights reserved.
//
#import "HomePageBackgroundView.h"

#import <QuartzCore/QuartzCore.h>

@interface HomePageBackgroundView : CALayer

@end
