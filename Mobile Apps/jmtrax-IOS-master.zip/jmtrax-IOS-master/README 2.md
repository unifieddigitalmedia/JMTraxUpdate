# Just-Money-Transfers-IOS-
Just Money Transfers is an IOS App 
This is the complete souce code for Just Money Transfers App which is waiting for completeion of user testing before being published to the Apple App store.
